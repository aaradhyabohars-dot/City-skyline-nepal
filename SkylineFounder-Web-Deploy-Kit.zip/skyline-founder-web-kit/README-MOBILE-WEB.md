# Skyline Founder — Browser Test Setup (phone only)

This publishes the included game ZIP to GitHub Pages. It does not create an APK.

## Files
- `SkylineFounder-Mobile.zip`: game source archive
- `.github/workflows/deploy.yml`: GitHub Actions workflow that builds and publishes the browser game

## Phone-only setup
1. In Chrome, sign in to https://github.com and create a **public** repository named `skyline-founder-web` with the default branch `main`.
2. Open the repository and use **Add file → Upload files**. Upload `SkylineFounder-Mobile.zip` from Downloads, then commit it to `main`.
3. In the repository, choose **Add file → Create new file**. Set the filename to `.github/workflows/deploy.yml` (include the folders and leading dot). Paste the complete contents of the separate `deploy.yml` file from this kit, then commit to `main`.
4. Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**, if it is not already set.
5. Open **Actions**. Select **Deploy Skyline Founder Web Game** and, if needed, tap **Run workflow**. A push to `main` also starts it automatically.
6. Wait for the run to finish successfully. Open **Settings → Pages** or the workflow's deployment environment to find the published `https://<your-username>.github.io/skyline-founder-web/` address.
7. Open that address in Samsung Internet or Chrome on the S25 Ultra. Use Chrome's menu → **Add to Home screen** if you want a shortcut.

## Notes
- GitHub Pages publishes the site publicly. Do not upload passwords, keys, or private information.
- The live URL cannot be generated until the user creates the repository and GitHub finishes deployment.
- This is an early 3D prototype, not a full Cities: Skylines-scale simulation. Internet is required to open the hosted game.
- If the workflow fails, open Actions → failed run → failed step and share a screenshot of the error.
